
public class Droid1 {
  Droid1(){
	 
	//  while(gc.Droid1Alive) {
	//	  gc.Droid1X=gc.Droid1X-1;
	 // }
  }
  public static void run() {
	//  GenosisChar gc=new GenosisChar();
//	  gc.Droid1X=gc.Droid1X+5;
  }
}
