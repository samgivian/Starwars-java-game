
public class DrawTrooper {

}
